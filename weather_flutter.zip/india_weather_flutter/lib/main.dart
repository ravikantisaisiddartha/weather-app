import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
  debugShowCheckedModeBanner: false,
  home: IndiaWeather(),
));

class IndiaWeather extends StatefulWidget {
  const IndiaWeather({super.key});

  @override
  State<IndiaWeather> createState() => _IndiaWeatherState();
}

class _IndiaWeatherState extends State<IndiaWeather> {
  final search = TextEditingController();
  String location = 'Hyderabad, Telangana';
  String condition = 'Partly Cloudy';
  int temperature = 28;
  int humidity = 65;
  int wind = 12;

  final regions = <String, String>{
    'Andhra Pradesh': 'Amaravati',
    'Arunachal Pradesh': 'Itanagar',
    'Assam': 'Dispur',
    'Bihar': 'Patna',
    'Chhattisgarh': 'Raipur',
    'Goa': 'Panaji',
    'Gujarat': 'Gandhinagar',
    'Haryana': 'Chandigarh',
    'Himachal Pradesh': 'Shimla',
    'Jharkhand': 'Ranchi',
    'Karnataka': 'Bengaluru',
    'Kerala': 'Thiruvananthapuram',
    'Madhya Pradesh': 'Bhopal',
    'Maharashtra': 'Mumbai',
    'Manipur': 'Imphal',
    'Meghalaya': 'Shillong',
    'Mizoram': 'Aizawl',
    'Nagaland': 'Kohima',
    'Odisha': 'Bhubaneswar',
    'Punjab': 'Chandigarh',
    'Rajasthan': 'Jaipur',
    'Sikkim': 'Gangtok',
    'Tamil Nadu': 'Chennai',
    'Telangana': 'Hyderabad',
    'Tripura': 'Agartala',
    'Uttar Pradesh': 'Lucknow',
    'Uttarakhand': 'Dehradun',
    'West Bengal': 'Kolkata',
    'Andaman and Nicobar Islands': 'Sri Vijaya Puram',
    'Chandigarh': 'Chandigarh',
    'Dadra and Nagar Haveli and Daman and Diu': 'Daman',
    'Delhi': 'New Delhi',
    'Jammu and Kashmir': 'Srinagar',
    'Ladakh': 'Leh',
    'Lakshadweep': 'Kavaratti',
    'Puducherry': 'Puducherry',
  };

  String selected = 'Telangana';

  void showWeather(String city) {
    city = city.trim();
    if (city.isEmpty) return;

    final match = regions.entries.where((e) =>
      e.key.toLowerCase() == city.toLowerCase() ||
      e.value.toLowerCase() == city.toLowerCase()
    );

    setState(() {
      if (match.isNotEmpty) {
        selected = match.first.key;
        location = '${match.first.value}, ${match.first.key}';
      } else {
        location = '$city, India';
      }

      // Demonstration values only, not live weather.
      temperature = 24 + city.length % 10;
      humidity = 50 + city.length % 35;
      wind = 5 + city.length % 15;
      condition = city.length % 2 == 0
          ? 'Partly Cloudy'
          : 'Sunny';
      search.text = city;
    });
    FocusScope.of(context).unfocus();
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF8DD9FF);
    const card = Color(0xFF263D69);

    return Scaffold(
      backgroundColor: const Color(0xFF101C3C),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF172D59),
              Color(0xFF101C3C),
              Color(0xFF263D69)
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    const Icon(Icons.cloud,
                        size: 48, color: accent),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text('India Weather',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 25,
                              fontWeight: FontWeight.bold)),
                          Text('WEATHER ACROSS INDIA',
                            style: TextStyle(
                              color: Colors.white60,
                              letterSpacing: 2,
                              fontSize: 10)),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () =>
                        showWeather(regions[selected]!),
                      icon: const Icon(Icons.refresh,
                          color: Colors.white),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20),
                child: DropdownButtonFormField<String>(
                  value: selected,
                  isExpanded: true,
                  dropdownColor: card,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Select state / union territory',
                    labelStyle: const TextStyle(color: accent),
                    prefixIcon: const Icon(Icons.map,
                        color: accent),
                    filled: true,
                    fillColor: card,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  items: regions.keys.map((region) =>
                    DropdownMenuItem(
                      value: region,
                      child: Text(region,
                          overflow: TextOverflow.ellipsis),
                    )).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      selected = value;
                      showWeather(regions[value]!);
                    }
                  },
                ),
              ),

              const SizedBox(height: 14),

              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20),
                child: TextField(
                  controller: search,
                  style: const TextStyle(color: Colors.white),
                  onSubmitted: showWeather,
                  decoration: InputDecoration(
                    hintText: 'Search an Indian city or state',
                    hintStyle:
                        const TextStyle(color: Colors.white54),
                    prefixIcon: const Icon(Icons.search,
                        color: accent),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.arrow_forward,
                          color: Colors.white),
                      onPressed: () => showWeather(search.text),
                    ),
                    filled: true,
                    fillColor: card,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: card,
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Column(
                          children: [
                            const Text('CURRENT WEATHER',
                              style: TextStyle(
                                color: Colors.white60,
                                letterSpacing: 2)),
                            const SizedBox(height: 15),
                            Text(location,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 19,
                                fontWeight: FontWeight.bold)),
                            const SizedBox(height: 20),
                            const Icon(Icons.wb_sunny,
                              size: 85, color: Color(0xFFFFD166)),
                            Text('$temperature°C',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 65,
                                fontWeight: FontWeight.w300)),
                            Text(condition,
                              style: const TextStyle(
                                color: accent, fontSize: 19)),
                            const SizedBox(height: 8),
                            Text('Feels like ${temperature + 2}°C',
                              style: const TextStyle(
                                color: Colors.white70)),
                          ],
                        ),
                      ),

                      const SizedBox(height: 22),

                      const Align(
                        alignment: Alignment.centerLeft,
                        child: Text('WEATHER DETAILS',
                          style: TextStyle(
                            color: Colors.white70,
                            letterSpacing: 2,
                            fontWeight: FontWeight.bold)),
                      ),

                      const SizedBox(height: 12),

                      GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics:
                            const NeverScrollableScrollPhysics(),
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 1.3,
                        children: [
                          metric(Icons.water_drop,
                              'Humidity', '$humidity%', card, accent),
                          metric(Icons.air,
                              'Wind Speed', '$wind km/h', card, accent),
                          metric(Icons.thermostat,
                              'Feels Like', '${temperature + 2}°C',
                              card, accent),
                          metric(Icons.umbrella,
                              'Precipitation', '0.0 mm', card, accent),
                        ],
                      ),

                      const SizedBox(height: 22),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: card,
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            const Text('5-Day Forecast',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold)),
                            const SizedBox(height: 16),
                            for (int i = 0; i < 5; i++)
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(
                                        vertical: 12),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        ['Today', 'Wed', 'Thu',
                                         'Fri', 'Sat'][i],
                                        style: const TextStyle(
                                          color: Colors.white)),
                                    ),
                                    Icon(
                                      i == 2
                                          ? Icons.cloud
                                          : Icons.wb_sunny,
                                      color: accent),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        i == 2 ? 'Cloudy' : 'Sunny',
                                        style: const TextStyle(
                                          color: Colors.white70)),
                                    ),
                                    Text(
                                      '${temperature + 4 - i}°',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold)),
                                    const SizedBox(width: 15),
                                    Text(
                                      '${temperature - 4 + i}°',
                                      style: const TextStyle(
                                        color: Colors.white60)),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),
                      const Text(
                        'DEMO VERSION • SAMPLE WEATHER DATA',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 10,
                          letterSpacing: 1.3),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget metric(IconData icon, String title, String value,
      Color card, Color accent) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: accent, size: 27),
          const SizedBox(height: 10),
          Text(title,
            style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Text(value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}