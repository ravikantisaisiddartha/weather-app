# India Weather — Flutter Demo

A Flutter weather UI with a state/union-territory dropdown, city search, current-weather card, weather details, and a 5-day forecast.

**Important:** This is a UI demonstration. Weather values are sample values and are not live weather data.

## Run the app

1. Install Flutter and set up your Flutter SDK.
2. Extract this ZIP.
3. Open a terminal in the `india_weather_flutter` folder.
4. Run:

   ```bash
   flutter pub get
   flutter run
   ```

To run in Chrome, use `flutter run -d chrome`.

## Main file

`lib/main.dart`
